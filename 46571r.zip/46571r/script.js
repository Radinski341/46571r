//------Hide and show element-----
$(document).ready(function(){
  $("#hide").click(function(){
    $(".hide-show-element").hide();
  });
  $("#show").click(function(){
    $(".hide-show-element").show();
  });
});
//--------Animation------------
$(document).ready(function(){
  $(".start-anim").click(function(){
    $(".anim-div").animate({left: '80%'});
  });
});
$(document).ready(function(){
  $(".reverse-anim").click(function(){
    $(".anim-div").animate({left: '0%'});
  });
});
//--------Mobile navigation----------
$(document).ready(function(){
  $("#flip").click(function(){
    $("#panel").slideToggle("slow");
  });
});